package Testing;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Race.Athlete;
import Race.Race;
import Race.RaceStuff;

public class RaceTest {

	@Test
    public void testValidConstruction() throws Exception {   
    	RaceStuff race = new Race();
    }
	
}
