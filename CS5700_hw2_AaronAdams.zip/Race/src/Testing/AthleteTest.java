package Testing;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Race.Athlete;
import Race.AthleteGrabber;
import Race.RaceStuff;
import Race.Subject;

public class AthleteTest {

	@Test
    public void testValidConstruction() throws Exception {   
    	RaceStuff athlete = new Athlete();
    }

}
