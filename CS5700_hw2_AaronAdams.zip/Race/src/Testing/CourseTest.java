package Testing;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Race.Athlete;
import Race.Course;
import Race.RaceStuff;

public class CourseTest {

	@Test
    public void testValidConstruction() throws Exception {   
    	RaceStuff course = new Course();
    }

}
