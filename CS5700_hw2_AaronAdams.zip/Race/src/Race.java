package Race;
import java.util.ArrayList;

public class Race extends RaceStuff{
	
	public Updates updateType;
	
	public Race (){
			
		super();
		
		updateType = new ItUpdates();
	}
	
}
